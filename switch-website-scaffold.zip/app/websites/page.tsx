"use client"

import { useI18n } from "@/components/i18n-context"
import { Button } from "@/components/ui/button"
import { Layers, Monitor, Phone, Tablet } from "lucide-react"

export default function WebsitesPage() {
  const { t } = useI18n()

  const projects = [
    { title: "Alpha Tech", desc: "Corporate landing page for SaaS solutions." },
    { title: "Lumina Studio", desc: "Minimalist portfolio for creative agencies." },
    { title: "Verge Commerce", desc: "High-conversion e-commerce storefront." },
    { title: "Nexus App", desc: "Interactive mobile-first dashboard." },
  ]

  const templates = [
    { type: "Hero Section", name: "Blackout Hero" },
    { type: "Feature Section", name: "Bento Grid v2" },
    { type: "Pricing Page", name: "Clean Tier" },
    { type: "Contact Form", name: "Minimal Send" },
    { type: "Footer", name: "Brutalist Base" },
    { type: "Navigation", name: "Blur Nav" },
  ]

  return (
    <div className="flex flex-col">
      {/* Header Section */}
      <section className="border-b py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-black tracking-tighter sm:text-7xl uppercase mb-4">{t("websites")}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            A curated showcase of high-performance digital architectures designed and built by SWITCH.
          </p>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 gap-12 md:grid-cols-2">
            {projects.map((project, i) => (
              <div key={i} className="group flex flex-col space-y-4">
                <div className="aspect-video relative overflow-hidden border bg-muted group-hover:border-foreground transition-colors">
                  {/* iframe placeholder */}
                  <div className="absolute inset-0 flex items-center justify-center bg-background p-4">
                    <div className="w-full h-full border border-dashed flex flex-col items-center justify-center text-muted-foreground">
                      <Monitor className="h-10 w-10 mb-2 opacity-20" />
                      <p className="text-xs uppercase font-bold tracking-widest">Live Preview Placeholder</p>
                    </div>
                  </div>
                  <div className="absolute top-4 right-4 flex gap-2">
                    <div className="bg-background border p-1 rounded-sm">
                      <Monitor className="h-3 w-3" />
                    </div>
                    <div className="bg-background border p-1 rounded-sm">
                      <Tablet className="h-3 w-3" />
                    </div>
                    <div className="bg-background border p-1 rounded-sm">
                      <Phone className="h-3 w-3" />
                    </div>
                  </div>
                </div>
                <div className="flex items-end justify-between">
                  <div>
                    <h3 className="text-2xl font-black tracking-tighter uppercase">{project.title}</h3>
                    <p className="text-muted-foreground">{project.desc}</p>
                  </div>
                  <Button variant="outline" className="font-bold bg-transparent">
                    Build Similar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Templates Section */}
      <section className="bg-foreground text-background py-24 border-t">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
            <div className="max-w-xl">
              <h2 className="text-4xl font-black tracking-tighter sm:text-5xl uppercase mb-4">Unlimited Templates</h2>
              <p className="text-background/60 text-lg">
                Access our entire library of pre-built sections and components for one fixed price. No complexity, just
                raw speed.
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs uppercase font-bold tracking-widest text-background/40 mb-2">Lifetime Access</p>
              <div className="text-5xl font-black tracking-tighter">$499</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
            {templates.map((template, i) => (
              <div
                key={i}
                className="group relative aspect-square border border-background/20 p-6 flex flex-col justify-between hover:bg-background hover:text-foreground transition-all cursor-pointer"
              >
                <div className="bg-background/10 group-hover:bg-foreground/10 p-2 w-fit">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold tracking-widest opacity-40 group-hover:opacity-100">
                    {template.type}
                  </p>
                  <p className="font-black text-sm uppercase">{template.name}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button className="bg-background text-foreground hover:bg-background/90 font-black px-12 h-14 uppercase">
              Browse Entire Library
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
